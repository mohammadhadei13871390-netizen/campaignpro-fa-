# CampaignPro فارسی 🚀

دستیار تخصصی طراحی و تحلیل کمپین فروش با Python + Streamlit + OpenAI Responses API.

## 1) نصب Python

Python 3.9 یا بالاتر نصب کن.

## 2) ساخت محیط مجازی

### Windows
```powershell
python -m venv .venv
.venv\Scripts\activate
```

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 3) نصب کتابخانه‌ها

```bash
pip install -r requirements.txt
```

## 4) تنظیم API Key

پوشه `.streamlit` را نگه دار و فایل زیر را بساز:

`.streamlit/secrets.toml`

محتوا:

```toml
OPENAI_API_KEY = "کلید-واقعی-تو"
```

کلید API را داخل `app.py` قرار نده.

## 5) اجرای برنامه

```bash
streamlit run app.py
```

مرورگر باز می‌شود و برنامه را در آدرس محلی Streamlit می‌بینی.

## 6) استفاده

در نوار سمت راست اطلاعات پروژه را وارد کن:

- محصول
- قیمت
- مخاطب
- هدف
- بودجه
- کانال
- مدت
- پیشنهاد ویژه

بعد در چت درخواستت را بنویس.

مثال:

```text
برای این محصول یک کمپین فروش 7 روزه طراحی کن.
```

## نکته امنیتی

فایل `.streamlit/secrets.toml` حاوی کلید خصوصی است و نباید در GitHub عمومی قرار بگیرد.

## استقرار آنلاین

می‌توانی پروژه را در GitHub قرار بدهی و آن را روی Streamlit Community Cloud منتشر کنی. هنگام Deploy، مقدار `OPENAI_API_KEY` را در بخش Secrets سرویس وارد کن.
