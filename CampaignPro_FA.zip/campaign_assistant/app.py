import os
import streamlit as st
from openai import OpenAI

st.set_page_config(
    page_title="CampaignPro فارسی",
    page_icon="🚀",
    layout="wide",
)

SYSTEM_PROMPT = """
تو CampaignPro فارسی هستی؛ یک دستیار تخصصی استراتژی، طراحی و کپی‌رایتینگ کمپین فروش.

ماموریت:
به کاربر کمک کن کمپین‌های فروش حرفه‌ای، قابل اجرا و قابل اندازه‌گیری طراحی کند.
تو فقط متن تبلیغاتی تولید نمی‌کنی؛ ابتدا مسئله کسب‌وکار، مخاطب، پیشنهاد و قیف فروش را تحلیل می‌کنی.

اصول:
1) اگر اطلاعات حیاتی ناقص است، قبل از طراحی نهایی حداکثر 7 سؤال اولویت‌دار بپرس.
2) واقعیت، فرض و پیشنهاد را از هم جدا کن.
3) وعده فروش قطعی نده و ادعاهای اثبات‌نشده را به‌عنوان واقعیت ننویس.
4) متن تبلیغاتی را بر اساس مرحله قیف و هدف آن بنویس.
5) اگر ایده کاربر ضعیف است، مستقیم توضیح بده چرا و جایگزین پیشنهاد کن.
6) همیشه CTA روشن ارائه کن.
7) در تحلیل کمپین از KPIهای مرتبط مثل CTR، CVR، CAC، AOV، ROAS و ROI استفاده کن؛ فقط وقتی داده کافی وجود دارد عددگیری کن.
8) برای تست A/B فرضیه مشخص، متغیر مورد تست و معیار موفقیت پیشنهاد بده.
9) خروجی‌ها فارسی، دقیق، اجرایی و بدون حاشیه باشند.
10) اگر کاربر درخواست «کمپین کامل» داد، ساختار زیر را رعایت کن:

1. خلاصه اجرایی
2. تحلیل محصول/خدمت
3. مخاطب هدف
4. دردها و انگیزه‌های خرید
5. موانع و اعتراضات
6. پیشنهاد فروش (Offer)
7. پیام اصلی کمپین
8. زاویه‌های تبلیغاتی
9. قیف فروش
10. برنامه محتوایی
11. متن‌های تبلیغاتی
12. CTAها
13. تست‌های A/B
14. KPIها
15. ریسک‌ها و نقاط ضعف
16. اقدامات بعدی

وقتی کاربر فقط «متن تبلیغ» می‌خواهد:
- هدف، مخاطب، پیشنهاد و کانال را بررسی کن.
- اگر اطلاعات حیاتی وجود ندارد، سؤال کوتاه بپرس.
- سپس متن را با 2 یا 3 زاویه متفاوت ارائه بده.

لحن:
حرفه‌ای، مستقیم، تحلیلی و فارسی روان.
"""

def get_api_key():
    # Streamlit secrets
    try:
        key = st.secrets.get("OPENAI_API_KEY")
        if key:
            return key
    except Exception:
        pass

    # Environment variable
    return os.getenv("OPENAI_API_KEY")


def call_model(messages, model):
    api_key = get_api_key()
    if not api_key:
        raise RuntimeError(
            "کلید OPENAI_API_KEY پیدا نشد. آن را در .streamlit/secrets.toml "
            "یا متغیر محیطی OPENAI_API_KEY قرار بده."
        )

    client = OpenAI(api_key=api_key)

    # Responses API supports a list of role/content messages as input.
    response = client.responses.create(
        model=model,
        instructions=SYSTEM_PROMPT,
        input=messages,
    )
    return response.output_text


if "messages" not in st.session_state:
    st.session_state.messages = []

if "project" not in st.session_state:
    st.session_state.project = {
        "product": "",
        "price": "",
        "audience": "",
        "goal": "",
        "budget": "",
        "channel": "",
        "duration": "",
        "offer": "",
    }

st.title("🚀 CampaignPro فارسی")
st.caption("دستیار تخصصی طراحی، اجرای متنی و تحلیل کمپین فروش")

with st.sidebar:
    st.header("⚙️ تنظیمات")

    model = st.selectbox(
        "مدل",
        ["gpt-5.5", "gpt-5.4-mini"],
        index=0,
    )

    st.divider()
    st.subheader("📦 اطلاعات پروژه")

    p = st.session_state.project
    p["product"] = st.text_input("محصول / خدمت", p["product"])
    p["price"] = st.text_input("قیمت", p["price"])
    p["audience"] = st.text_area("مخاطب هدف", p["audience"])
    p["goal"] = st.text_input("هدف کمپین", p["goal"])
    p["budget"] = st.text_input("بودجه تبلیغات", p["budget"])
    p["channel"] = st.text_input("کانال فروش / تبلیغات", p["channel"])
    p["duration"] = st.text_input("مدت کمپین", p["duration"])
    p["offer"] = st.text_area("پیشنهاد ویژه / تخفیف / هدیه", p["offer"])

    if st.button("🧹 شروع پروژه جدید", use_container_width=True):
        st.session_state.messages = []
        st.session_state.project = {
            "product": "",
            "price": "",
            "audience": "",
            "goal": "",
            "budget": "",
            "channel": "",
            "duration": "",
            "offer": "",
        }
        st.rerun()

    st.divider()
    st.info(
        "کلید API را داخل کد قرار نده. برای اجرای محلی از "
        ".streamlit/secrets.toml استفاده کن."
    )

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

if not st.session_state.messages:
    st.markdown(
        """
### 👋 آماده‌ام.

مثلاً بنویس:

> برای یک کانال لوازم آرایشی، کمپین فروش ۷ روزه طراحی کن.

یا:

> این محصول را بررسی کن و بگو چرا فروشش پایین است.

اطلاعات پروژه را هم می‌توانی از ستون سمت راست وارد کنی.
"""
    )

prompt = st.chat_input("درخواست کمپین‌نویسی خودت را بنویس...")

if prompt:
    project_text = "\n".join(
        [
            "اطلاعات پروژه فعلی:",
            f"- محصول/خدمت: {p['product'] or 'نامشخص'}",
            f"- قیمت: {p['price'] or 'نامشخص'}",
            f"- مخاطب: {p['audience'] or 'نامشخص'}",
            f"- هدف: {p['goal'] or 'نامشخص'}",
            f"- بودجه: {p['budget'] or 'نامشخص'}",
            f"- کانال: {p['channel'] or 'نامشخص'}",
            f"- مدت: {p['duration'] or 'نامشخص'}",
            f"- پیشنهاد ویژه: {p['offer'] or 'نامشخص'}",
        ]
    )

    user_content = f"{project_text}\n\nدرخواست کاربر:\n{prompt}"

    st.session_state.messages.append(
        {"role": "user", "content": prompt}
    )

    with st.chat_message("user"):
        st.markdown(prompt)

    api_messages = []
    for m in st.session_state.messages:
        api_messages.append(
            {"role": m["role"], "content": m["content"]}
        )

    # Replace the latest user message with the enriched project context.
    api_messages[-1] = {"role": "user", "content": user_content}

    with st.chat_message("assistant"):
        with st.spinner("در حال تحلیل کمپین..."):
            try:
                answer = call_model(api_messages, model)
                st.markdown(answer)
                st.session_state.messages.append(
                    {"role": "assistant", "content": answer}
                )
            except Exception as exc:
                error = f"❌ خطا: {exc}"
                st.error(error)
                st.session_state.messages.append(
                    {"role": "assistant", "content": error}
                )
